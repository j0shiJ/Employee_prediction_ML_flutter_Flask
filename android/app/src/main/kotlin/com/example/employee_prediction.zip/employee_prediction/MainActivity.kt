package com.example.employee_prediction

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
